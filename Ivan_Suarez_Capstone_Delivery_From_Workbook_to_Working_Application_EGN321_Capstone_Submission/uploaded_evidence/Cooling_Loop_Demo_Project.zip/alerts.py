def classify_alert(temp_c, flow_lpm):
    alerts = []

    if temp_c is not None and temp_c >= 30:
        alerts.append("HIGH_TEMPERATURE")

    if flow_lpm is not None and flow_lpm < 25:
        alerts.append("LOW_FLOW")

    return alerts or ["NORMAL"]
