# Cooling Loop Reliability Monitor

## Project Overview
This demo project replaces a legacy Cooling Loop Operations Workbook with a more trustworthy engineering-software workflow.

The original workbook tracked:
- temperature in Celsius;
- pressure in kPa;
- flow in L/min;
- operator notes;
- legacy status;
- temperature alerts;
- flow alerts;
- data-quality status.

## Original Artifact
`EGN321_Module8_Demo_Original_Artifact_STUDENT.xlsx`

## System Requirements
- Python 3.10+
- pandas
- Flask
- pytest
- plotly
- SQLite
- Web browser

## Quick Start
1. Install the required Python packages.
2. Place the 720-record CSV in the project data folder.
3. Run the analysis or application.
4. Confirm that all 720 records are loaded.
5. Review the dashboard, validation results, and alert conditions.
6. Review the log and failure/recovery evidence.

## Inputs and Units
- Temperature: degrees Celsius
- Pressure: kilopascals
- Flow: liters per minute
- Timestamp: local date/time
- Operator Note: free text

## Supported Ranges
- Temperature: 0–60 °C
- Pressure: 50–400 kPa
- Flow: 0–200 L/min

## What the Tool Refuses
The improved application should refuse:
- missing required values;
- temperature outside 0–60 °C;
- pressure outside 50–400 kPa;
- flow outside 0–200 L/min;
- malformed or unsupported input structures.

## Known Legacy Weaknesses
The inherited workbook has two important limitations:
1. `Legacy_Status` evaluates temperature but does not fully account for pressure and flow.
2. The legacy low-flow alert uses 20 L/min, while the intended engineering threshold for this demo is 25 L/min.

These weaknesses are intentionally preserved in the original artifact so the capstone can demonstrate how the application improves on the spreadsheet.

## Normal Operation
A successful run should:
1. load all records;
2. validate engineering ranges;
3. preserve raw evidence;
4. classify accepted/rejected input;
5. calculate health and alert state;
6. store or display history;
7. generate analysis and reporting.

## Logs
Operational evidence is provided in:
`system_log_demo.jsonl`

## Tests
Run:
`pytest -q`

The supplied test-results file demonstrates the expected demo outcome.

## Failure / Recovery
The demo includes a controlled missing-database scenario and recovery evidence in:
`failure_recovery_evidence.md`

## Assumptions
- Temperature values are Celsius.
- Pressure values are kPa.
- Flow values are L/min.
- The 720-row dataset is the reference demo dataset.
- The intended low-flow alert threshold is 25 L/min.

## Known Limitations
- This is a classroom simulation and does not verify physical sensor calibration.
- It does not implement production authentication or high availability.
- The original workbook contains intentionally weak legacy logic for instructional purposes.

## AI Use
AI may help review documentation, summarize deterministic evidence, challenge conclusions, and suggest tests.

AI must not invent evidence or replace deterministic verification.
