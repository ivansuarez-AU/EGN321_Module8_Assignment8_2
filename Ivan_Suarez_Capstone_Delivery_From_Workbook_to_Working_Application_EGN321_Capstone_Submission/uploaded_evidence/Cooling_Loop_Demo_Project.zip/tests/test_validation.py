from validation import validate_reading
from alerts import classify_alert

def test_known_correct_case():
    result = validate_reading(24.0, 210.0, 82.0)
    assert result["accepted"] is True

def test_temperature_out_of_range_refused():
    result = validate_reading(86.0, 210.0, 82.0)
    assert result["accepted"] is False

def test_pressure_out_of_range_refused():
    result = validate_reading(24.0, 485.0, 82.0)
    assert result["accepted"] is False

def test_missing_flow_refused():
    result = validate_reading(24.0, 210.0, None)
    assert result["accepted"] is False

def test_high_temperature_alert():
    assert "HIGH_TEMPERATURE" in classify_alert(31.0, 82.0)

def test_low_flow_uses_25_lpm_threshold():
    assert "LOW_FLOW" in classify_alert(24.0, 22.0)

def test_normal_reading_has_no_alert():
    assert classify_alert(24.0, 82.0) == ["NORMAL"]
