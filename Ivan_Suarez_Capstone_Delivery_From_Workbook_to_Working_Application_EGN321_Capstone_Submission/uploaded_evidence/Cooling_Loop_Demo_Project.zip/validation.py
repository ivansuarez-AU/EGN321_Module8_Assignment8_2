def validate_reading(temp_c, pressure_kpa, flow_lpm):
    reasons = []

    if temp_c is None:
        reasons.append("temperature missing")
    elif not 0 <= temp_c <= 60:
        reasons.append(f"temperature out of range: {temp_c}")

    if pressure_kpa is None:
        reasons.append("pressure missing")
    elif not 50 <= pressure_kpa <= 400:
        reasons.append(f"pressure out of range: {pressure_kpa}")

    if flow_lpm is None:
        reasons.append("flow missing")
    elif not 0 <= flow_lpm <= 200:
        reasons.append(f"flow out of range: {flow_lpm}")

    return {
        "accepted": len(reasons) == 0,
        "reasons": reasons
    }
